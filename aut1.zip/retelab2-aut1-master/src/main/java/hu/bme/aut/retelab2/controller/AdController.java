package hu.bme.aut.retelab2.controller;

import hu.bme.aut.retelab2.domain.Ad;
import hu.bme.aut.retelab2.domain.SecretGenerator;
import hu.bme.aut.retelab2.repository.AdRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/ad")
public class AdController {

    @Autowired
    private AdRepository adRepository;


    @PostMapping("/save")
    public ResponseEntity<String> saveAd(@RequestBody Ad ad) {
        try{
            String secret = SecretGenerator.generate();
            ad.setDateOfCreation(LocalDateTime.now());
            ad.setSecretCode(secret);
            adRepository.save(ad);
            return ResponseEntity.ok(secret);
        }
        catch (Exception e){
            return ResponseEntity.badRequest().build();
        }
    }

    @GetMapping("/findByMinMax")
    public List<Ad> getAll(@RequestParam(required = false, defaultValue = "0") int min,@RequestParam(required = false, defaultValue = "10000000") int max) {
        List<Ad> foundAds = adRepository.findByMinMax(min,max);
        for (Ad ad: foundAds
             ) {
            ad.setSecretCode(null);
        }
        return foundAds;
    }

    @PutMapping("/update")
    public ResponseEntity<Ad> update(@RequestBody Ad a){
        try {
            return ResponseEntity.ok(adRepository.updateAd(a)) ;
        }
        catch (Exception e){
            return ResponseEntity.status(403).build();
        }
    }

    @GetMapping("/ads/{tag}")
    public List<Ad> findByTag(@PathVariable String tag){
        return adRepository.findByTag(tag);
    }
}
