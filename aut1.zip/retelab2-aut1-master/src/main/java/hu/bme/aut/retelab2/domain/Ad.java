package hu.bme.aut.retelab2.domain;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity
public class Ad {
    @Id
    @GeneratedValue
    private Long id;
    private String title;
    private String desc;
    private int price;
    private LocalDateTime dateOfCreation;
    public String secretCode;
    @ElementCollection
    @CollectionTable(name="tags")
    private List<String> tags ;

    public Long getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price){ this.price=price; }

    public LocalDateTime getDateOfCreation(){return this.dateOfCreation;}
    public void setDateOfCreation(LocalDateTime ldt){this.dateOfCreation=ldt;}

    public String getSecretCode() {
        return secretCode;
    }

    public void setSecretCode(String sc) {
        this.secretCode = sc;
    }

    public List<String> getTags(){
        return this.tags;
    }

    public void setTags(List<String> tags){
        this.tags = tags;
    }

}
